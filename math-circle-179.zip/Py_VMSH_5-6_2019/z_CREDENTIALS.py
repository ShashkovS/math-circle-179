FTP_BAS_CRED = ('host1000218_vtn', 'utgqKKg2EX')
JSON_DB_BAS_CRED = ('shashkov_test_json', 'QAhuMpXpvh')
FTP_PRO_CRED = ('host1000218_vta', 'hqa57xdxmD')
JSON_DB_PRO_CRED = ('shashkov_test_json', 'QAhuMpXpvh')
