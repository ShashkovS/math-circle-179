FTP_BAS_CRED = ('host1000218_vmn', '')
JSON_DB_BAS_CRED = ('shashkov', '')
FTP_PRO_CRED = ('host1000218_vma', '')
JSON_DB_PRO_CRED = ('shashkov', '')
